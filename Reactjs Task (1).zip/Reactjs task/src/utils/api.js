// utils/api.js

// Mock user data
export const mockUsers = [
  { id: "1", username: "admin", email: "admin@example.com", role: "admin" },
  { id: "2", username: "user1", email: "user1@example.com", role: "user" },
  { id: "3", username: "user2", email: "user2@example.com", role: "user" },
  { id: "4", username: "user3", email: "user3@example.com", role: "user" },
  { id: "5", username: "user4", email: "user4@example.com", role: "user" },
  { id: "6", username: "user5", email: "user5@example.com", role: "user" },
  { id: "7", username: "user6", email: "user6@example.com", role: "user" },
  { id: "8", username: "user7", email: "user7@example.com", role: "user" },
  { id: "9", username: "user8", email: "user8@example.com", role: "user" },
  { id: "10", username: "user9", email: "user9@example.com", role: "user" },
];

// Mock API functions
export const getUsers = () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockUsers);
    }, 1000);
  });
};

export const getUserById = (id) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const user = mockUsers.find((user) => user.id === id);
      resolve(user);
    }, 1000);
  });
};

export const updateUser = (id, newData) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      mockUsers.forEach((user) => {
        if (user.id === id) {
          Object.assign(user, newData);
        }
      });
      resolve(newData);
    }, 1000);
  });
};

export const createUser = (newUser) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const id = (mockUsers.length + 1).toString();
      const userWithId = { ...newUser, id };
      mockUsers.push(userWithId);
      resolve(userWithId);
    }, 1000);
  });
};

export const deleteUser = (id) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const index = mockUsers.findIndex((user) => user.id === id);
      if (index !== -1) {
        mockUsers.splice(index, 1);
      }
      resolve();
    }, 1000);
  });
};
