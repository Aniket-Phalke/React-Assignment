import React from "react";

const UserList = ({ users, onSelectUser }) => (
  <div>
    <h2>User List</h2>
    <ul>
      {users.map((user) => (
        <li key={user.id} onClick={() => onSelectUser(user.id)}>
          {user.username} - {user.email} - {user.role}
        </li>
      ))}
    </ul>
  </div>
);

export default UserList;
