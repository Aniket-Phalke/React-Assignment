import React from "react";

const EditUserModal = ({ user, onClose, onSave }) => (
  <div>
    <h2>Edit User</h2>
    <form onSubmit={onSave}>
      <label>Username:</label>
      <input type="text" defaultValue={user.username} />
      <label>Email:</label>
      <input type="email" defaultValue={user.email} />
      <label>Role:</label>
      <select defaultValue={user.role}>
        <option value="admin">Admin</option>
        <option value="user">User</option>
      </select>
      <button type="submit">Save</button>
      <button onClick={onClose}>Cancel</button>
    </form>
  </div>
);

export default EditUserModal;
