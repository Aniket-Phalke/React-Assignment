import React from "react";

const DeleteConfirmationDialog = ({ user, onCancel, onDelete }) => (
  <div>
    <p>Are you sure you want to delete {user.username}?</p>
    <button onClick={onDelete}>Yes</button>
    <button onClick={onCancel}>No</button>
  </div>
);

export default DeleteConfirmationDialog;
