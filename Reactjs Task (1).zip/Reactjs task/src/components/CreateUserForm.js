import React from "react";

const CreateUserForm = ({ onSubmit }) => (
  <div>
    <h2>Create User</h2>
    <form onSubmit={onSubmit}>
      <label>Username:</label>
      <input type="text" />
      <label>Email:</label>
      <input type="email" />
      <label>Role:</label>
      <select>
        <option value="admin">Admin</option>
        <option value="user">User</option>
      </select>
      <button type="submit">Create</button>
    </form>
  </div>
);

export default CreateUserForm;
