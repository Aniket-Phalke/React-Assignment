// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import UsersPage from './pages/UsersPage';
import UserDetailsPage from './pages/UserDetailsPage';

const App = () => (
  <Router>
    <Switch>
      <Route path="/users/:userId" component={UserDetailsPage} />
      <Route path="/users" component={UsersPage} />
      <Route path="/" component={UsersPage} />
    </Switch>
  </Router>
);

export default App;
