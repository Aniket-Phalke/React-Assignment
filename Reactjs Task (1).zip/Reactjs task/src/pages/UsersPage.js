import React, { useState } from "react";
import UserList from "../components/UserList";
import { mockUsers } from "../utils/api";

const UsersPage = ({ history }) => {
  const [users, setUsers] = useState(mockUsers);

  const handleSelectUser = (userId) => {
    history.push(`/users/${userId}`);
  };

  return (
    <div>
      <h1>User Management Dashboard</h1>
      <UserList users={users} onSelectUser={handleSelectUser} />
    </div>
  );
};

export default UsersPage;
