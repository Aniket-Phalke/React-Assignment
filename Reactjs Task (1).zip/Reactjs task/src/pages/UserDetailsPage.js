import React, { useState } from "react";
import UserDetails from "../components/UserDetails";
import EditUserModal from "../components/EditUserModal";
import DeleteConfirmationDialog from "../components/DeleteConfirmationDialog";
import { mockUsers } from "../utils/api";

const UserDetailsPage = ({ match, history }) => {
  const userId = match.params.userId;
  const user = mockUsers.find((user) => user.id === userId);
  const [isEditing, setIsEditing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleEditUser = () => {
    setIsEditing(true);
  };

  const handleCloseEdit = () => {
    setIsEditing(false);
  };

  const handleDeleteUser = () => {
    setIsDeleting(true);
  };

  const handleCloseDelete = () => {
    setIsDeleting(false);
  };

  const handleSaveUser = () => {
    // Implement save logic here
    setIsEditing(false);
  };

  const handleDeleteConfirmed = () => {
    // Implement delete logic here
    setIsDeleting(false);
    history.push("/users");
  };

  return (
    <div>
      {isEditing ? (
        <EditUserModal
          user={user}
          onClose={handleCloseEdit}
          onSave={handleSaveUser}
        />
      ) : (
        <UserDetails
          user={user}
          onEditUser={handleEditUser}
          onDeleteUser={handleDeleteUser}
        />
      )}
      {isDeleting && (
        <DeleteConfirmationDialog
          user={user}
          onCancel={handleCloseDelete}
          onDelete={handleDeleteConfirmed}
        />
      )}
    </div>
  );
};

export default UserDetailsPage;
